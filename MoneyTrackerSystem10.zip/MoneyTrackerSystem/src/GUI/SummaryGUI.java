/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package GUI;
import model.MoneyTracker;
import service.MoneyService;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import java.awt.Image;
/**
 *
 * @author Administrator
 */
public class SummaryGUI extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(SummaryGUI.class.getName());
    private MoneyTracker user;
    /**
     * Creates new form SummaryGUI
     */
    public SummaryGUI() {
        initComponents();
    }
    
    public SummaryGUI(MoneyTracker user) {
        initComponents();
        
        
        //Wallet
        ImageIcon icon = new ImageIcon(
            getClass().getResource("/images/—Pngtree—vector wallet icon_4276183.png")
        );
        
        Image img = icon.getImage();
        Image scaledImg = img.getScaledInstance(50, 50, Image.SCALE_SMOOTH);
        
        lblMoneyIcon.setIcon(new ImageIcon(scaledImg));
        
        //Piggy Bank
        ImageIcon piggyIcon = new ImageIcon(
            getClass().getResource("/images/pig-removebg-preview.png")
        );
        
        Image piggyImg = piggyIcon.getImage();
        Image piggyScaledImg = piggyImg.getScaledInstance(50, 50, Image.SCALE_SMOOTH);
        
        lblSavedIcon.setIcon(new ImageIcon(piggyScaledImg));
        
        //Shopping Cart
        ImageIcon cartIcon = new ImageIcon(
            getClass().getResource("/images/cart-removebg-preview.png")
        );
        
        Image cartImg = cartIcon.getImage();
        Image cartScaledImg = cartImg.getScaledInstance(50, 50, Image.SCALE_SMOOTH);
        
        lblCartIcon.setIcon(new ImageIcon(cartScaledImg));
        
        //Star
        ImageIcon starIcon = new ImageIcon(
            getClass().getResource("/images/star-removebg-preview.png")
        );
        
        Image starImg = starIcon.getImage();
        Image starScaledImg = starImg.getScaledInstance(50, 50, Image.SCALE_SMOOTH);
        
        lblStarIcon.setIcon(new ImageIcon(starScaledImg));
        
        //Food
        ImageIcon foodIcon = new ImageIcon(
            getClass().getResource("/images/food-removebg-preview.png")
        );
        
        Image foodImg = foodIcon.getImage();
        Image foodScaledImg = foodImg.getScaledInstance(50, 50, Image.SCALE_SMOOTH);
        
        lblFoodIcon.setIcon(new ImageIcon(foodScaledImg));
        
        //Logo (same picture)
        ImageIcon logoIcon = icon;
        
        Image logoImg = logoIcon.getImage();
        Image logoScaledImg = logoImg.getScaledInstance(50, 50, Image.SCALE_SMOOTH);
        
        lblLogoIcon.setIcon(new ImageIcon(logoScaledImg));
        
        
        
        
        
        
        
        this.user = user;
        loadSummary();
    }
    
    private void loadSummary() {
         
        try {
            // Money Spent, Necessities, Wants and Food are for the
            // CURRENT month only, so they restart from zero every month.
            double spent =
                    MoneyService.getMonthlySpent(user.getIdNumber());

            // Money Saved does NOT restart: it carries over every month.
            double saved =
                    MoneyService.getTotalSaved(user.getIdNumber());
            
            
            

            double necessities =
                    MoneyService.getMonthlyCategoryTotal(
                            user.getIdNumber(), "Necessities");

            double wants =
                    MoneyService.getMonthlyCategoryTotal(
                            user.getIdNumber(), "Wants");

            double food =
                    MoneyService.getMonthlyCategoryTotal(
                            user.getIdNumber(), "Food");
            
            lblMoneySpent.setText(String.format("₱%.2f", spent));
            lblNecessities.setText(String.format("₱%.2f", necessities));
            lblWants.setText(String.format("₱%.2f", wants));
            lblFood.setText(String.format("₱%.2f", food));

            if (saved < 0) {
                lblMoneySaved.setText(
                        String.format("₱%.2f", saved)
                );
                lblMoneySaved.setForeground(java.awt.Color.RED);
            } else {
                lblMoneySaved.setText(
                        String.format("₱%.2f", saved)
                );
                lblMoneySaved.setForeground(java.awt.Color.BLACK);
            }
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                    "Error loading summary: " + e.getMessage()
            );
        }
    }
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new BackgroundSummary();
        jPanel2 = new GUI.RoundedPanel();
        jPanel3 = new GUI.RoundedPanel();
        jPanel6 = new GUI.RoundedPanel();
        lblSavedIcon = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        lblMoneySaved = new javax.swing.JLabel();
        jPanel5 = new GUI.RoundedPanel();
        lblMoneySpent = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        lblMoneyIcon = new javax.swing.JLabel();
        jPanel7 = new GUI.RoundedPanel();
        jLabel4 = new javax.swing.JLabel();
        lblCartIcon = new javax.swing.JLabel();
        jPanel10 = new javax.swing.JPanel();
        lblNecessities = new javax.swing.JLabel();
        jPanel8 = new GUI.RoundedPanel();
        jLabel5 = new javax.swing.JLabel();
        lblStarIcon = new javax.swing.JLabel();
        jPanel11 = new javax.swing.JPanel();
        lblWants = new javax.swing.JLabel();
        jPanel9 = new GUI.RoundedPanel();
        jLabel6 = new javax.swing.JLabel();
        lblFoodIcon = new javax.swing.JLabel();
        jPanel12 = new javax.swing.JPanel();
        lblFood = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        btnUpdateMoney = new javax.swing.JButton();
        btnBAck = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        lblLogoIcon = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(102, 204, 255));
        jPanel1.setMaximumSize(null);
        jPanel1.setPreferredSize(new java.awt.Dimension(1400, 720));

        jPanel2.setBackground(new java.awt.Color(73, 109, 255));

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));

        jPanel6.setBackground(new java.awt.Color(204, 102, 255));
        jPanel6.setMaximumSize(null);
        jPanel6.setPreferredSize(new java.awt.Dimension(215, 100));

        lblSavedIcon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/pig-removebg-preview.png"))); // NOI18N
        lblSavedIcon.setText(" ");
        lblSavedIcon.setPreferredSize(new java.awt.Dimension(50, 50));

        jLabel3.setFont(new java.awt.Font("Verdana", 1, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(102, 0, 102));
        jLabel3.setText("Money Available");

        lblMoneySaved.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lblMoneySaved.setForeground(new java.awt.Color(102, 0, 102));
        lblMoneySaved.setText("₱0.00");

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(lblSavedIcon, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3)
                    .addComponent(lblMoneySaved))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                .addContainerGap(20, Short.MAX_VALUE)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblSavedIcon, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(lblMoneySaved)))
                .addGap(11, 11, 11))
        );

        jPanel5.setBackground(new java.awt.Color(200, 200, 250));
        jPanel5.setMaximumSize(null);
        jPanel5.setPreferredSize(new java.awt.Dimension(288, 100));

        lblMoneySpent.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lblMoneySpent.setForeground(new java.awt.Color(0, 0, 153));
        lblMoneySpent.setText("₱0.00");

        jLabel1.setFont(new java.awt.Font("Verdana", 1, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 153));
        jLabel1.setText("Money Spent");

        lblMoneyIcon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/—Pngtree—vector wallet icon_4276183.png"))); // NOI18N
        lblMoneyIcon.setText(" ");
        lblMoneyIcon.setMaximumSize(null);
        lblMoneyIcon.setMinimumSize(null);
        lblMoneyIcon.setPreferredSize(null);

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(lblMoneyIcon, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblMoneySpent)
                    .addComponent(jLabel1))
                .addContainerGap(81, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(lblMoneyIcon, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(18, 18, 18)
                        .addComponent(lblMoneySpent)))
                .addContainerGap(18, Short.MAX_VALUE))
        );

        jPanel7.setBackground(new java.awt.Color(204, 255, 204));
        jPanel7.setMaximumSize(null);
        jPanel7.setPreferredSize(new java.awt.Dimension(728, 39));

        jLabel4.setFont(new java.awt.Font("Verdana", 1, 14)); // NOI18N
        jLabel4.setText("Necessities");

        lblCartIcon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/cart-removebg-preview.png"))); // NOI18N
        lblCartIcon.setMaximumSize(new java.awt.Dimension(50, 50));
        lblCartIcon.setMinimumSize(new java.awt.Dimension(50, 50));
        lblCartIcon.setPreferredSize(new java.awt.Dimension(50, 50));

        jPanel10.setMaximumSize(new java.awt.Dimension(165, 40));
        jPanel10.setMinimumSize(new java.awt.Dimension(165, 40));
        jPanel10.setPreferredSize(new java.awt.Dimension(165, 40));

        lblNecessities.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lblNecessities.setText("₱0.00");

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel10Layout.createSequentialGroup()
                .addContainerGap(112, Short.MAX_VALUE)
                .addComponent(lblNecessities)
                .addContainerGap())
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel10Layout.createSequentialGroup()
                .addContainerGap(9, Short.MAX_VALUE)
                .addComponent(lblNecessities)
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblCartIcon, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 46, Short.MAX_VALUE)
                .addComponent(jPanel10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jPanel10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addComponent(jLabel4)
                        .addGap(9, 9, 9)))
                .addContainerGap(17, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblCartIcon, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        jPanel8.setBackground(new java.awt.Color(255, 204, 102));
        jPanel8.setMaximumSize(null);
        jPanel8.setPreferredSize(new java.awt.Dimension(728, 39));

        jLabel5.setFont(new java.awt.Font("Verdana", 1, 14)); // NOI18N
        jLabel5.setText("Wants");

        lblStarIcon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/star-removebg-preview.png"))); // NOI18N
        lblStarIcon.setMaximumSize(new java.awt.Dimension(50, 50));
        lblStarIcon.setMinimumSize(new java.awt.Dimension(50, 50));
        lblStarIcon.setPreferredSize(new java.awt.Dimension(50, 50));

        jPanel11.setMaximumSize(new java.awt.Dimension(165, 40));
        jPanel11.setMinimumSize(new java.awt.Dimension(165, 40));
        jPanel11.setPreferredSize(new java.awt.Dimension(165, 40));

        lblWants.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lblWants.setText("₱0.00");

        javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel11Layout.createSequentialGroup()
                .addContainerGap(112, Short.MAX_VALUE)
                .addComponent(lblWants)
                .addContainerGap())
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblWants)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblStarIcon, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel8Layout.createSequentialGroup()
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jPanel11, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel8Layout.createSequentialGroup()
                                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(11, 11, 11)))
                        .addGap(28, 28, 28))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel8Layout.createSequentialGroup()
                        .addComponent(lblStarIcon, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18))))
        );

        jPanel9.setBackground(new java.awt.Color(255, 102, 102));
        jPanel9.setMaximumSize(null);
        jPanel9.setPreferredSize(new java.awt.Dimension(469, 80));

        jLabel6.setFont(new java.awt.Font("Verdana", 1, 14)); // NOI18N
        jLabel6.setText("Food");

        lblFoodIcon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/food-removebg-preview.png"))); // NOI18N
        lblFoodIcon.setMaximumSize(new java.awt.Dimension(50, 50));
        lblFoodIcon.setMinimumSize(new java.awt.Dimension(50, 50));
        lblFoodIcon.setPreferredSize(new java.awt.Dimension(50, 50));

        jPanel12.setMaximumSize(new java.awt.Dimension(165, 40));
        jPanel12.setMinimumSize(new java.awt.Dimension(165, 40));
        jPanel12.setPreferredSize(new java.awt.Dimension(165, 40));

        lblFood.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lblFood.setText("₱0.00");

        javax.swing.GroupLayout jPanel12Layout = new javax.swing.GroupLayout(jPanel12);
        jPanel12.setLayout(jPanel12Layout);
        jPanel12Layout.setHorizontalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel12Layout.createSequentialGroup()
                .addContainerGap(112, Short.MAX_VALUE)
                .addComponent(lblFood)
                .addContainerGap())
        );
        jPanel12Layout.setVerticalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel12Layout.createSequentialGroup()
                .addContainerGap(9, Short.MAX_VALUE)
                .addComponent(lblFood)
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblFoodIcon, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addGap(17, 17, 17)
                        .addComponent(jPanel12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblFoodIcon, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel6))))
                .addContainerGap(9, Short.MAX_VALUE))
        );

        jPanel4.setBackground(new java.awt.Color(204, 204, 204));
        jPanel4.setMaximumSize(null);
        jPanel4.setPreferredSize(new java.awt.Dimension(5, 280));

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 5, Short.MAX_VALUE)
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 280, Short.MAX_VALUE)
        );

        btnUpdateMoney.setBackground(new java.awt.Color(0, 51, 255));
        btnUpdateMoney.setFont(new java.awt.Font("SansSerif", 1, 12)); // NOI18N
        btnUpdateMoney.setForeground(new java.awt.Color(255, 255, 255));
        btnUpdateMoney.setText("🔄    UPDATE MONEY");
        btnUpdateMoney.addActionListener(this::btnUpdateMoneyActionPerformed);

        btnBAck.setBackground(new java.awt.Color(102, 102, 102));
        btnBAck.setFont(new java.awt.Font("SansSerif", 1, 12)); // NOI18N
        btnBAck.setForeground(new java.awt.Color(255, 255, 255));
        btnBAck.setText("🡸       BACK");
        btnBAck.addActionListener(this::btnBAckActionPerformed);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(btnBAck, javax.swing.GroupLayout.PREFERRED_SIZE, 340, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 35, Short.MAX_VALUE)
                        .addComponent(btnUpdateMoney, javax.swing.GroupLayout.PREFERRED_SIZE, 340, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, 288, Short.MAX_VALUE)
                            .addComponent(jPanel5, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jPanel9, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 386, Short.MAX_VALUE)
                            .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, 386, Short.MAX_VALUE)
                            .addComponent(jPanel8, javax.swing.GroupLayout.DEFAULT_SIZE, 386, Short.MAX_VALUE))))
                .addContainerGap(21, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(51, 51, 51)
                        .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(22, 22, 22)
                        .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(36, 36, 36)
                        .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnUpdateMoney, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnBAck, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(16, Short.MAX_VALUE))
        );

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Summary");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(53, 53, 53)
                .addComponent(jLabel2)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(0, 6, Short.MAX_VALUE)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        lblLogoIcon.setText(" ");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(lblLogoIcon, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(592, Short.MAX_VALUE)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(57, 57, 57))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(5, 5, 5)
                .addComponent(lblLogoIcon, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(110, 110, 110)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(140, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 12, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnBAckActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBAckActionPerformed
        // TODO add your handling code here:
        SpendingGUI spending = new SpendingGUI(user);
        spending.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnBAckActionPerformed

    private void btnUpdateMoneyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUpdateMoneyActionPerformed
        // TODO add your handling code here:
        String input = JOptionPane.showInputDialog(
            this,
            "Enter amount to ADD to your current money:"
    );

    if (input == null || input.trim().isEmpty()) {
       return;
    }

    try {
        double additionalMoney = Double.parseDouble(input);

        if (additionalMoney <= 0) {
            JOptionPane.showMessageDialog(
                   this,
                    "Please enter a valid amount."
            );
            return;
        }

        double newIncome = user.getIncome() + additionalMoney;

        boolean success = MoneyService.updateIncome(
               user.getIdNumber(),
                newIncome
        );

        if (success) {
            MoneyService.addIncomeHistory(
                user.getIdNumber(),
                additionalMoney
            );

            user.setIncome(newIncome);
            
            loadSummary();

            JOptionPane.showMessageDialog(
                    this,
                    "Money updated successfully!\n"
                    + "New total: ₱"
                    + String.format("%.2f", newIncome)
            );

        } else {
            JOptionPane.showMessageDialog(
                    this,
                    "Failed to update money."
            );
        }

    } catch (NumberFormatException e) {

        JOptionPane.showMessageDialog(
                this,
                "Please enter a valid number."
        );
    }
    }//GEN-LAST:event_btnUpdateMoneyActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new SummaryGUI().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBAck;
    private javax.swing.JButton btnUpdateMoney;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JLabel lblCartIcon;
    private javax.swing.JLabel lblFood;
    private javax.swing.JLabel lblFoodIcon;
    private javax.swing.JLabel lblLogoIcon;
    private javax.swing.JLabel lblMoneyIcon;
    private javax.swing.JLabel lblMoneySaved;
    private javax.swing.JLabel lblMoneySpent;
    private javax.swing.JLabel lblNecessities;
    private javax.swing.JLabel lblSavedIcon;
    private javax.swing.JLabel lblStarIcon;
    private javax.swing.JLabel lblWants;
    // End of variables declaration//GEN-END:variables
}
